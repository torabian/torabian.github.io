# Meshora Thermo

In this folder, we have a complete build of the Meshora Thermo for ESP32 series.

To make it easier, for windows users, use flash.bat, and for linux users you can use flash.sh


## How to flash it to device?

To make it easier, I've placed booth ./esptool (linux amd64) and ./esptool.exe (windows amd64) inside the product package.

Just use `./flash.sh` or `./flash.bat` to make it easy.


For mac or other types, you can download the esp tool from here: https://github.com/espressif/esptool/releases

and modify the flash.sh for mac.