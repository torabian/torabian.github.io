#!/bin/bash
  cd "$(dirname "$0")"
  ./esptool --chip esp32 -b 460800 --before default_reset --after hard_reset write_flash --flash_mode dio --flash_size 2MB --flash_freq 40m 0x1000 bootloader/bootloader.bin 0x8000 partition_table/partition-table.bin 0x10000 sdcard.bin 0x110000 storage.bin
  