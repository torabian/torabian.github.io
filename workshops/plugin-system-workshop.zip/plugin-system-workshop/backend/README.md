# Welcome to a fireback backend project :)

This is a boilerplate which would be provided via `fireback new` or downloadable from github releases since v1.2.1

- Make sure you have installed golang, and make.
- run `make` :D 

Running and developing Fireback project needs some knowledge about Module3 format, creating development
environment and so far, so take some time to learn the Framework.

You can modify this boilerplate and continue building your project.

Make sure you have updated the go.mod for go module name if you needed.

It's the same API as any other Fireback project, so read more on:

https://torabian.github.io/fireback

**Also check for the VSCode plugins needed on the docs**, there is autocompletion, run on save or more
to help you have easier life.

With Love, Ali