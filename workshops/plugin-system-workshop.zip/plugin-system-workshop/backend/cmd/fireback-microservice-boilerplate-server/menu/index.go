package menu

import "embed"

//go:embed *
var Menu embed.FS
