import{j as t}from"./index-CXdu0MBE.js";const s=()=>t.jsx("h1",{children:"About"});export{s as default};
