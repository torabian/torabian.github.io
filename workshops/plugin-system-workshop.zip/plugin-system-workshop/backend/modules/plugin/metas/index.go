package metas

import "embed"

//go:embed *
var MetaFs embed.FS

