package queries

import "embed"

//go:embed *
var QueriesFs embed.FS

