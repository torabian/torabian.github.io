package seeders

import "embed"

//go:embed *
var ViewsFs embed.FS
