import './App.css'
import { PluginPage } from './PluginPage'

function App() {
  return (
    <>
      <PluginPage />
    </>
  )
}

export default App
